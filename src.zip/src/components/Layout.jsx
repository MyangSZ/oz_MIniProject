import NavBar from "./NavBar";

function Layout() {
  return (
    <div>
      <NavBar />
    </div>
  );
}

export default Layout;
