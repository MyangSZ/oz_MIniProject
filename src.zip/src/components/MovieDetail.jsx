import { useParams } from "react-router";

import movielist from "../data/movieListData.json";

function MovieDetail() {
  const { results } = movielist;
  const { movie_id } = useParams();

  const moviedetail = results.find((id) => id.id === Number(movie_id));
  // const { title, average, genres, overview } = moviedetail;
  return (
    <>
      <div>
        <h1>dslkfslkdjflskdjflkjsdlfasdlfkjsdklfj</h1>
        {/* {title}
        {average}
        {genres}
        {overview} */}
      </div>
    </>
  );
}

export default MovieDetail;
